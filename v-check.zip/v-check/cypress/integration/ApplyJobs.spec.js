/// <reference types="Cypress" />


context('Login as Candidate', () => {
  beforeEach(() => {
    cy.visit('https://oceans-group.staging.krakatoa.aus-2.volcanic.cloud/')
  })
  it('It should go to the login page after clicking the login button', () => {

      cy.get('#header #top-links li a').click()
      cy.url().should('equal', 'https://oceans-group.staging.krakatoa.aus-2.volcanic.cloud/users/login')
      cy.get('#email').type('dharma@volcanic.co.uk')
      cy.get('#password').type('Dharma1234@')
      cy.get('[type="submit"]').click()

  })
});

context('Applying job', () => {
    beforeEach(() => {
      cy.visit('https://oceans-group.staging.krakatoa.aus-2.volcanic.cloud/jobs')
    })
    it('It should go to the apply now page after clicking the apply button', () => {

        cy.get('.job-result-item:first-of-type .extra-job-links .job-apply-now-link').click()
        cy.url().should('equal', 'https://oceans-group.staging.krakatoa.aus-2.volcanic.cloud/job/digital-marketing-and-brand-manager/apply')
        cy.get('#job_application_first_name').type('Dharma')
        cy.get('#job_application_last_name').type('Seelan')
        cy.get('#job_application_email').type('dharma@volcanic.co.uk')
        
        const fileName = 'resume_test.pdf';
        cy.fixture(fileName).then(fileContent => {
          cy.get('[type="file"]').upload({ fileContent, fileName, mimeType: 'application/pdf' });
        });
        cy.get('[type="submit"]').click()

    })
});






